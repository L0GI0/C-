#include "kobieta.h"
Kobieta::Kobieta(std::string  n_name):Osoba(n_name){
  
}