#pragma once 

class MapPoint{
	public:
		//Drugi konstruktor przyjmujacy odpowiednie koordynaty 
		MapPoint(double lat, double lon);
		//Domyslny konstruktor
		MapPoint();
		//Destruktor
		~MapPoint();
		//Metoda wypisujaca koordynat objektu klasy MapPoint zawarte w zmiennych prywatnych
		void print() const;
		//Zmienia koordynaty obiektu o przeslane wartosci
		void move(double lat, double lon);
		//Metoda statyczna zwiazana z klasa zwracajaca obiekt klasy MapPoint 
		// zawierajacy koordynaty miejsca ktore wskazuje srodek pomiedzy koordynatami dwoch przeslanych obiektow przez wartosci
		static MapPoint inTheMiddle(const MapPoint & point1, const MapPoint & point2);
		//Metoda zwracajca obiekt ktory posiada koordynaty ktore znajduja sie dalej od koordynatow obiektu klasy MapPoint 
		MapPoint & furtherFrom(MapPoint & point1, MapPoint & point2) const;
		//Zwraca zmienna prywatna _lat klasy MapPoint
		inline double getLat() const{
			return _lat;
		}
		//Zwraca zmienna prywatna _lon klasy MapPoint
		inline double getLon() const{
			return _lon;
		}
		//Zmienna statyczna zwiazana z klasa przechowujaca liczbe aktualnie utworzonych Punktow (Obiektow)
		static int numberOfPoints;
	private:
		//Zmienne przechowujace koordynaty 
		double _lat;
		double _lon;
};