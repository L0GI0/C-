#pragma once
#include <string>

class Zelazko {
    public:
        Zelazko(float cena, const std::string &n) : z_cena(cena), z_nazwa(n) {}
        void UstawTemperature(int temp);
        void WypiszWlasciwosci();
        float getTemp() { return z_temp;}
    protected:
        float z_cena;
        float z_temp;
        std::string z_nazwa;
};

class ZelazkoZelmer : public Zelazko {
    public:
        ZelazkoZelmer(float cena) : Zelazko(cena, "Zelmer") {}
        void WypiszWlasciwosci();
};

class ZelazkoTefal : public Zelazko {
    public:
        ZelazkoTefal(float cena) : Zelazko(cena, "Tefal") {}
};