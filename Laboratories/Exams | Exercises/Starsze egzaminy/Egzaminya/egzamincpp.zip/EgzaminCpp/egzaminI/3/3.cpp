#include <iostream>
#include <fstream>
#include <iterator>
#include <algorithm>
// Uzupełnij 

int main(int argc, char** argv) { 
  if(argc == 3) { 
    std::ifstream in(argv[1]); 
    std::ofstream out(argv[2]); 
    std::copy(/*uzupełnij*/std::istreambuf_iterator<char>(in),std::istreambuf_iterator<char>(), /*uzupełnij*/ std::ostream_iterator<char>(out)); 
  } 
} 
