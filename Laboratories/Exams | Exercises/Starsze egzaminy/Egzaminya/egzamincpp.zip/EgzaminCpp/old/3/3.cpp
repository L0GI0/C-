#include <iostream>

template <typename T = double>
struct box{
  box(T d): data(d) {}
  T data;
  operator T() {
    return data;
  }
};


int main() {
  box<> b1 = 3.14;
  box<unsigned> b2 = 13;
  double d = b1;
  unsigned u = b2;
}
