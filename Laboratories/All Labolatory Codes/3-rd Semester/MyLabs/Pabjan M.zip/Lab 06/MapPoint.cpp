#include <iostream>
#include "MapPoint.h"
#include <math.h>

using namespace std;

int MapPoint::numberOfPoints;

MapPoint::MapPoint(double lat, double lon){
	//increase();
	 numberOfPoints++;
	_lat = lat;
	_lon = lon;
	cout << "Num of points = " << numberOfPoints << ", current Point (" <<  _lat << "N, " << _lon << "E)" << endl;
}

void MapPoint::print() const{
	if(_lat > 0)
	cout << "Point (" <<  _lat << "N, " << _lon << "E)" << endl;
	else cout << "Point (" <<  (-_lat) << "S, " << _lon << "E)" << endl;
}

void MapPoint::move(double lat, double lon){
	_lat += lat;
	_lon += lon;
}

MapPoint MapPoint::inTheMiddle(const MapPoint  & point1, const MapPoint & point2){
	double latMiddle, lonMiddle;
	latMiddle = (point1.getLat() + point2.getLat());
	lonMiddle = (point1.getLon() + point2.getLon());
	latMiddle /= 2;
	lonMiddle /= 2;

	static MapPoint temp = MapPoint(latMiddle, lonMiddle);
	return temp;
}

MapPoint & MapPoint::furtherFrom(MapPoint & point1, MapPoint & point2) const{
	double distance = sqrt(_lat * _lat + _lon * _lon);
	if (distance - sqrt(point1.getLon()* point1.getLon() + point1.getLat()*point1.getLat()) > distance - sqrt(point2.getLon()* point2.getLon() + point2.getLat()*point2.getLat()))
		return point1;
	else return point2;
}

MapPoint::~MapPoint(){
	 numberOfPoints--;
	
	cout << "Num of points " << numberOfPoints << endl;
};

