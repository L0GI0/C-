/////////////////////////////////////////////////////////////////////////
/// \file
/// \author Bartosz Mindur
/// \author mindur@fatcat.ftj.agh.edu.pl
/// \version 0.1
/// \date 27-09-2004
/// \brief First programme.
/////////////////////////////////////////////////////////////////////////

#include <iostream>
using namespace std;
int main(int argc, char * argv[])
{
	cout << "Witam\n";
}