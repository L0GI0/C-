#include <iostream>

template <unsigned int N>
class fibonacci {
public:
  static unsigned const int value = fibonacci<N-2>::value + fibonacci<N-1>::value;
};
template <>
class fibonacci<0> {
public:
  static unsigned const int value = 0;
};
template <>
class fibonacci<1> {
public:
  static unsigned const int value = 1;
};


//Dzisiaj króciutkie (i oczywiście te wartości się mają policzyć w
//czasie kompilacji)
/*UZUPEŁNIJ #1*/
int main(int argc, char* argv[])
{
       std::cout << fibonacci<19>::value << std::endl;
       std::cout << fibonacci<41>::value << std::endl;
       return 0;
}
/*
4181
165580141
*/
