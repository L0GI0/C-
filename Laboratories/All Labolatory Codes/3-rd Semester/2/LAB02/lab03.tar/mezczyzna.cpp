#include "mezczyzna.h"
Mezczyzna::Mezczyzna(std::string  n_name):Osoba(n_name){
  
}