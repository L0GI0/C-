#include <iostream>
#include <queue>

int main(int argc, char* argv[])
{
       typedef  std::priority_queue<std::pair<int, double> > Kol;
       Kol kolejka;
       std::pair<int, double> p1 = std::pair<int,double>(4,4.02);
       std::pair<int, double> p2 = std::pair<int,double>(2,2.03);
       std::pair<int, double> p3 = std::pair<int,double>(9,1.05);
       kolejka.push(std::make_pair(7,1.05));
       kolejka.push(p2);
       kolejka.push(p3);
       kolejka.push(p1);

       while(!kolejka.empty())
       {
               std::cout << kolejka.top().first << " " << kolejka.top().second << std::endl;
               kolejka.pop();
       }
       return 0;
}




/*Wyjście (posortowane malejąco)
9 1.05
7 1.05
4 4.02
2 2.03
*/
