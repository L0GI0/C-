#include "Ubranie.h"

Ubranie::Ubranie(float cena, std::string n) : u_cena(cena), u_nazwa(n), u_stan(false) {}

Koszula::Koszula(float c, std::string n) : Ubranie(c,n), r_stan(false) {}

Spodnie::Spodnie(float c, std::string x) : Ubranie(c,x), n_stan(false) {}

KoszulaBawelniana::KoszulaBawelniana(const float cena) : Koszula(cena, "Koszula bawelniana") {}

KoszulaJedwabna::KoszulaJedwabna(const float cena) : Koszula(cena, "Koszula jedwabna") {}

SpodnieBawelniane::SpodnieBawelniane(const float cena) : Spodnie(cena, "Spodnie bawelniane") {}

SpodnieJedwabne::SpodnieJedwabne(const float cena) : Spodnie(cena, "Spodnie jedwabne") {}

void Ubranie::WypiszWlasciwosci() {
    std::cout << u_nazwa << "- cena " << u_cena << ". Stan ubrania: " << (u_stan? "wyprasowane." : "pogniecione.");
}

void Koszula::WypiszWlasciwosci() {
    std::cout << u_nazwa << " - cena: " << u_cena << ". Stan ubrania: " << (u_stan? "wyprasowane." : "pogniecione.") << ". Stan rekawow: " << (r_stan? "wyprasowane." : "pogniecione.") << std::endl; 
}

void Spodnie::WypiszWlasciwosci() {
    std::cout << u_nazwa << " - cena: " << u_cena << ". Stan ubrania: " << (u_stan? "wyprasowane." : "pogniecione.") << ". Stan nogawek: " << (n_stan? "wyprasowane." : "pogniecione.") << std::endl; 
}

void Ubranie::Prasuj(Zelazko &z) {
    std::cout << "Prasuje " << u_nazwa <<" zelazkiem o temp. " << z.getTemp() << "." << std::endl;
    u_stan = "wyprasowane";
}

void Koszula::PrasujRekawy(Zelazko & z) {
    std::cout << "Prasuje 'rekawy " << u_nazwa << "' zelazkiem o temp." << z.getTemp() <<". " << std::endl;
    r_stan = 1;
}

void Spodnie::PrasujNogawki(Zelazko & z) {
    std::cout << "Prasuje 'nogawki " << u_nazwa << "' zelazkiem o temp." << z.getTemp() <<". " << std::endl;
    n_stan = 1;

}

void Ubranie::Pogniec() {
    u_stan = 0;
}

