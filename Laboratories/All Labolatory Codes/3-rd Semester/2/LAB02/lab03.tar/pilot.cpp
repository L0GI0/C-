#include "pilot.h"
Pilot::Pilot(std::string  n_name):Osoba(n_name){
  
}