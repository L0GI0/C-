#include <iostream>
#include <algorithm>
#include <iterator>


/*UZUPEŁNIJ #1*/
const char tab[] = {49, 44, 47, 49, 49, 97, 49, 44, 47, 49, 12, 47,
  49, 44, 52, 102, 97, 97, 49, 44, 47, 17, 44, 47, 49, 44,
  52, 99, 44, 47, 49, 44, 15, 49, 44, 47, 54, 75, 8, 99,44, 47, 49, 12,
  47, 49, 49, 37, 74, 45, 48, 99, 44, 47, 17, 44,
  52, 102, 97, 100, 102, 97, 100, 99, 44, 15, 49, 44, 47, 49, 126,
  -127, 49, 44, 47, 49, 12};

const char key[] = {7,2,5};

char encrypt(char c, const char * klucz, int k)
{
  static int i = -1;
  return c + klucz[i = (1 + i) % k];
}

/*UZUPEŁNIJ #2*/
void decrypt(char& c) {
  static int i = -1;
  c -= key[i = (1 + i) % 3];
}


int main(int argc, char* argv[])
{
  std::string str(tab);
  std::for_each(str.begin(),str.end(),decrypt);
  std::cout << str << std::endl;
  std::replace(str.begin(), str.end(), '*', ' '); //zamien gwiazdki na spacje

  std::copy(str.begin(), str.end(), std::ostream_iterator<char>(std::cout, "")); //wypisanie
  std::cout << std::endl;
  return 0;

}
