#include <iostream>
#include <stack>
#include <cstdlib>

class test {
public:
  test() {
    liczba++;
  }
  ~test() {
    liczba--;
  }
  void* operator new(size_t rozmiar) {
    void* wskaznik = malloc(rozmiar);
    if ( wskaznik == NULL) {
      std::cout << "Blad przy alokacji pamieci" << std::endl; //wyjatek i radzenie sobie z nim...
    }
    std::cout << "alokuje test. Zaalokowane: " << liczba << std::endl;
    return wskaznik;
  }
  void operator delete (void* wsk) {
    free(wsk);
    std::cout << "dealokuje test. Pozostalo: " << liczba << std::endl;
  }
private:
  static int liczba;
};

int test::liczba = 0;

int main(int argc, char* argv[])
{
       std::stack<test*> stos;
       for(int i=0;i<5;++i)
         stos.push(new test());
       for(;stos.size();)
       {
            delete stos.top();
            stos.pop(); //zwalnianie pamięci bez uzycia cout
       }


       return 0;
}

/*
alokuje test Zaalokowane: 1
alokuje test Zaalokowane: 2
alokuje test Zaalokowane: 3
alokuje test Zaalokowane: 4
alokuje test Zaalokowane: 5
ealokuje test Pozostalo: 4
dealokuje test Pozostalo: 3
dealokuje test Pozostalo: 2
dealokuje test Pozostalo: 1
dealokuje test Pozostalo: 0
*/
