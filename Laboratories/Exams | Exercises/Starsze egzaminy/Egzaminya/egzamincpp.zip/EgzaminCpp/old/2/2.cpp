#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

template <typename T>
ostream& operator<< (ostream& strumien, const vector<T>& v) {
  for(int i = 0; i < v.size(); ++i) {
    strumien << setw(5) << v[i] << " ";
  }
  /*
  for(typename vector<T>::iterator it = v.begin(); it != v.end(); it++) {
    strumien << setw(5) << *it;
  } */
  return strumien;
}

int main() {
  vector<int> veci;
  vector<double> vecd;

  for( int i = 0; i < 10; ++i) {
    veci.push_back(i);
    vecd.push_back(i * 1.1);
  }

  cout << veci << endl << vecd << endl;
  return 0;
}
