#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <iterator>
#include <algorithm>

class Object {  
public:
  virtual std::string print() = 0;
};

class TextObject: public Object {
public:
  std::string print() {
    return "TextObject";
  }
};

template <typename T>
class TextLine: public TextObject {
public:
  std::string print() {
    std::stringstream s;
    s << "TextLine: " << TxlLine;
    return s.str();
  }
  TextLine(T s): TxlLine(s) {}
private:
  T TxlLine;
};

class OpenGLObject: public Object {
  std::string print() {
    return "OpenGLObject";
  }
};

template <typename T>
class OpenGLLine: public OpenGLObject {
public:
  std::string print() {
    std::stringstream s;
    s << "OpenGLLine: " << GLString;
    return s.str();
  }
  OpenGLLine(T s): GLString(s) {}
private:
  T GLString;
};

std::ostream& operator<<(std::ostream& strumien, Object* o) {
  return strumien << o->print();
}

/*Uzupelnij #1*/

void clean_up(Object*& o) {
   delete o;
   o = NULL;
}

int main(int argc, char* argv[])
{
       std::vector<Object*> v;
       v.push_back(new OpenGLLine<std::string>("abrakadabra"));
       v.push_back(new TextLine<double>(3.50));
       v.push_back(new TextObject());
       v.push_back(new OpenGLObject());
       std::copy(v.begin(), v.end(), std::ostream_iterator<Object*>(std::cout,"\n")); //wypisywanie

       std::for_each(v.begin(), v.end(), clean_up); //zwalnianie pamieci
       return 0;
}


/*
OpenGLLine: abrakadabra
TextLine: 3.5
TextObject
OpenGLObject
*/
