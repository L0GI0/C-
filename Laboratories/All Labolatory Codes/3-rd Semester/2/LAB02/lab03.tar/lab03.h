#ifndef Lab03
#define Lab03
#include "kobieta.h"
#include "mezczyzna.h"
#include "postac.h"
#include "kurier.h"
#include "pilot.h"
#include "final.h"














#endif