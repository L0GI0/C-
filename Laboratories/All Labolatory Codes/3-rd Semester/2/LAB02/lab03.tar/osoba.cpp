#include "osoba.h"
Osoba::Osoba(std::string n_name){
    imie=n_name;
}