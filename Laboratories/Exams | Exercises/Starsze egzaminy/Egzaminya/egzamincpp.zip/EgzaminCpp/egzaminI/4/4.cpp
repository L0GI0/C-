#include <iostream>

template <typename T>
class box {
public:
  box(T d): data(d) {
  }
  void print() {
    std::cout << "Typ T = " << data << std::endl;
  }
private:
  T data;
};

template <>
class box<char> {
public:
  explicit box(char d): data(d) {
  }
  void print() {
    std::cout << "Typ char = " << data << std::endl;
  }
private:
  char data;
};


/*UZUPEŁNIJ*/ 
int main(){ 
  box<int> b1 = -1; 
  box<unsigned> b2 = 2; 
  box<double> b3 = 2.14; 
  box<char> b4 = box<char>('C'); 
  //odkomentowanie ponizszej linijki bedzie sygnalizowac blad, C w ASCII = 67 
  //box<char> b5 = 'C'; 
  b1.print(); //Wypisuje: Typ T = -1 
  b2.print(); //Wypisuje: Typ T = 2; 
  b3.print(); //WYpisuje: Typ T = 2.14; 
  b4.print(); //Wypisuje: Typ char = 67; 
}
