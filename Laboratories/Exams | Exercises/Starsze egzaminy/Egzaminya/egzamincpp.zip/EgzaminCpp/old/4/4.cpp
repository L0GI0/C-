#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Object {
  string text;
};

class PrintableText: public Object {
public:
  PrintableText(string s) {
    text = s;
  }
  void printf() {
    cout << text << std::endl;
  }
};

class DrawableText: public Object {
public:
  DrawableText(string s) {
    text = s;
  }
  void draw() {
    cout << text << std::endl;
  }
};

//uzupelnic #1
int main(){
  vector<Object*> vec; //uzupelnic #2 ;

  vec.push_back(new PrintableText("PrintableText 1"));
  vec.push_back(new DrawableText("DrawableText 1"));
  vec.push_back(new Object());

  const PrintableObject* po1 = static_cast<PrintableObject*>(vec[0]); 
  //uzupelnic #3 (vec[0]);
 // const DrawableObject& do1 = 
  //uzupelnic #4 (vec[1]);

  //po1->print();
  //do1.draw();

  //to ma nie dziaÂ łaĂŚ:
  //vec[0]->print();
  //vec[1]->draw();
  //uzpuelnic #5

}
