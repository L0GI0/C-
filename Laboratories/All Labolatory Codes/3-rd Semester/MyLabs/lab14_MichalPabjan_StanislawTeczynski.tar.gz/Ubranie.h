#pragma once
#include <iostream>
#include "Zelazko.h"
/* Klasa bazowa ubranie zapewniajaca funkcjonalnosci zwiazane z utworzeniem ubrania, wypisujaca wlasciwowsci
oraz z klasami pochodnymi "Koszula", "Spodnie" itd. */
class Ubranie {
    public:
/* Konstruktor dwuargumentowy, ustawiajacy nazwe ubrania na 'n' */
        Ubranie(float cena, std::string n);

/* Metoda wypisujaca parametry danego ubrania: cene, nazwe i stan(pognieciona/wyprasowana) */
        void WypiszWlasciwosci();

/* Metoda ustawiajaca stan ubrania na wyprasowane "prasuje ubranie" */
        void Prasuj(Zelazko & z);

/* Metoda ustawiajaca stan ubrania na pogniecione "gniecie ubranie" */
        void Pogniec();
    
    protected:
/* argumenty protected dostepne z poziomu klas pochodnych */
        float u_cena;
        std::string u_nazwa;
        bool u_stan;

};

/* Klasa pochodna Koszula */
class Koszula : public Ubranie {
    public:
        Koszula(float c, std::string n);
        void WypiszWlasciwosci();
        void PrasujRekawy(Zelazko & z);
    protected:
        bool r_stan;
};

class Spodnie : public Ubranie {
    public:
        Spodnie(float c, std::string x);
        void WypiszWlasciwosci();
        void PrasujNogawki(Zelazko & z);
    protected:
        bool n_stan;
};


class KoszulaBawelniana : public Koszula {
    public:
        KoszulaBawelniana(const float cena);
};

class KoszulaJedwabna : public Koszula {
    public:
        KoszulaJedwabna(const float cena);
};

class SpodnieBawelniane : public Spodnie {
    public:
        SpodnieBawelniane(const float cena);
};

class SpodnieJedwabne : public Spodnie {
    public:
        SpodnieJedwabne(const float cena);

};

