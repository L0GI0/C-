#include "Rational.h"
#include <iostream>


using namespace std;

void Rational::Print() const{
	std::cout << _licznik << "/" << _mianownik << std::endl;
}

Rational::Rational(){};


