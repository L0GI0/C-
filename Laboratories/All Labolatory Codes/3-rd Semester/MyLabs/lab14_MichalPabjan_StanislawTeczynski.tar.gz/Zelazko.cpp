#include "Zelazko.h"
#include <iostream>

void Zelazko::UstawTemperature(int temp) { z_temp = temp; }

void Zelazko::WypiszWlasciwosci() {  }

void ZelazkoZelmer::WypiszWlasciwosci() { 
    std::cout << "Zelazko Zelmer cena: " << z_cena <<". temperatura: " << z_temp << std::endl; 
}

