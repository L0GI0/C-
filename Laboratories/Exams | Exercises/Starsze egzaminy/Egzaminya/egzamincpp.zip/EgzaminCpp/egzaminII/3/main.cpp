#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <algorithm>
#include <iterator>

std::string foo() {
  static int licznik = 0;
  if (licznik == 0) {
    licznik ++;
    return "hello";
  } else {
    licznik --;
    return "aaa";
  }
}

bool IsHello (const std::string& s) {
  if( s == "hello") 
    return true;
  else
    return false;
}


int main(int argc, char* argv[])
{
       std::vector<std::string> vec(20);
       std::multiset <std::string, std::greater<std::string> > set;
       set.insert("abrakadabra");
       std::generate_n(vec.begin(),20,foo); //wstawianie na zmiane hello i aaa
       std::copy(vec.begin(), vec.end(), std::inserter(set, set.end())); //wstawianie vectora do set
       std::cout << "ilosc hello to: "<< count_if(set.begin(), set.end(), IsHello) << std::endl;


       std::copy(set.begin(), set.end(), std::ostream_iterator<std::string>(std::cout,"\n"));
}


/*
ilosc hello w set to: 10
hello
hello
hello
hello
hello
hello
hello
hello
hello
hello
abrakadabra
aaa
aaa
aaa
aaa
aaa
aaa
aaa
aaa
aaa
aaa
*/
