#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>

using namespace std;

class Person
{
	public :
		Person() {}
		Person(const char * imie, const char * nazw) : _imie(imie), _nazw(nazw) {}
		friend ostream & operator<<(ostream & os, const Person per);
	private :
		string _imie;
		string _nazw;
};

ostream & operator<<(ostream & os, const Person per)
{
	os << per._imie << " " << per._nazw;
}

int main ()
{
	typedef list<Person> kontener_typ;
	kontener_typ c;
	c.insert(c.begin(),Person("Nowak","Jan"));
	c.insert(c.begin(),Person("Nowak","Adam"));
	c.insert(c.begin(),Person("Kowalski","Jan"));	
	c.insert(c.begin(),Person("Iksinski","Adam"));
	std::copy (c.begin(), c.end(), ostream_iterator<Person>(cout, ", "));
}


//Wynika działania:
//Iksinski Adam, Kowalski Jan, Nowak Adam, Nowak Jan,

