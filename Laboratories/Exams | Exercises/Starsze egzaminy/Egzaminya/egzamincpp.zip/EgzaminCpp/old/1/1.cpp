#include <iostream>
#include <list>
#include <algorithm>
#include <iterator>
#include <string>
#include <functional>

class Person {
public:
  Person(std::string n = "name"): name(n) {}
  std::string name;
};

void print(const Person& p) {
  std::cout << "Name: " << p.name << std::endl;
}

bool isWord(Person p, std::string s) {
  if (p.name == s) return true;
  return false;
}

int main(int argc, char* argv[]) {
  typedef std::list<Person> l;
  l lista;
  Person p1("Adam");
  Person p2("Krzysztof");
  Person p3("Bill");
  Person p4("Steven");

  lista.insert(lista.end(), p1);
  lista.insert(lista.end(), p2);
  lista.insert(lista.end(), p3);
  lista.insert(lista.end(), p4);

  for_each(lista.begin(), lista.end(), print); 
  std::string szukane("Steven");
  l::iterator it;
  it = find_if(lista.begin(), lista.end(), std::bind2nd(std::ptr_fun(isWord),szukane));
  if (it != lista.end()) {
    std::cout << "Znaleziono!" << std::endl;
  }

  
  return 0;
}
