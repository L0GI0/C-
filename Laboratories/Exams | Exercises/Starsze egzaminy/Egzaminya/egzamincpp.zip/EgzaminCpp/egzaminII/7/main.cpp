#include <iostream>
#include <string>

template <typename T>
struct swapper {
  static void swap(T t1, T t2) {
    T tmp;
    tmp = t1;
    t1 = t2;
    t2 = tmp;
  }
};
template <typename T>
struct swapper <T*> {
  static void swap(T* t1, T* t2) {
    T tmp;
    tmp = *t1;
    *t1 = *t2;
    *t2 = tmp;
  }
};

template <typename T>
struct swapper<T&> {
  static void swap(T& t1, T& t2) {
    T tmp;
    tmp = t1;
    t1 = t2;
    t2 = tmp;
  }
};

template <typename T>
struct swapper <T*&> {
  static void swap(T*& t1, T*& t2) {
    T* tmp;
    tmp = t1;
    t1 = t2;
    t2 = tmp;
  }
};


/*UZUPEŁNIJ #2*/
int main(int argc, char* argv[])
{
  int a=10,b=15;
  int * p1 = &a;
  int * p2 = &b;
  std::cout << p1 << "=" << *p1 << " " << p2 << "=" << *p2 << " a=" <<
    a << " b=" << b <<std::endl;
  swapper<int*>::swap(p1,p2);
  std::cout << p1 << "=" << *p1 << " " << p2 << "=" << *p2 << " a=" <<
  a << " b=" << b <<std::endl;
  swapper<int>::swap(a,b);
  std::cout << p1 << "=" << *p1 << " " << p2 << "=" << *p2 << " a=" <<
    a << " b=" << b <<std::endl;
  swapper<int&>::swap(a,b);
  std::cout << p1 << "=" << *p1 << " " << p2 << "=" << *p2 << " a=" <<
    a << " b=" << b <<std::endl;
  swapper<int*&>::swap(p1,p2);
  std::cout << p1 << "=" << *p1 << " " << p2 << "=" << *p2 << " a=" <<
    a << " b=" << b <<std::endl;
  return 0;
}

/* takie lub podobne
   001AFC70=10 001AFC64=15 a=10 b=15
   001AFC70=15 001AFC64=10 a=15 b=10
   001AFC70=15 001AFC64=10 a=15 b=10
   001AFC70=10 001AFC64=15 a=10 b=15
   001AFC64=15 001AFC70=10 a=10 b=15
 */
