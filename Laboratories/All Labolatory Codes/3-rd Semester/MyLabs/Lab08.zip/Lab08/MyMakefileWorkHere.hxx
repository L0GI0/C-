#pragma once 
#include "Rational.h"
#include "Fun.h"


