#include <iostream>
#include <list>
#include <algorithm>
#include <iterator>
using namespace std;

struct A
{
	void operator()(int & i) { static int x = -1; i = x--; }	//x = i--;
	//static int x = -1;
};

int main()
{
	list<int> coll(11);	
	for_each(coll.begin(), coll.end(), A());
	copy(coll.begin(), coll.end(), ostream_iterator<int>(cout, "; "));
	return 0;
}
