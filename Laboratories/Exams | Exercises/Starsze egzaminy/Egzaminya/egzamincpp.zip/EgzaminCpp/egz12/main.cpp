#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>
using namespace std;

struct A
{
	int operator()() { static int i = -1; return i--; }
};

void printer(const int & x)
{
	cout << x << "; ";
}


int main(int argc, char** argv) 
{ 
  std::list<int> col; 
  //template <class OutputIterator, class Size, class Generator>
  //  void generate_n ( OutputIterator first, Size n, Generator generate ) 
	gen_n(back_inserter(col), 9, A());
	for_each(col.begin(), col.end(), printer);	// wypisanie pierwszy sposób
	copy(col.begin(), col.end(), ostream_iterator<int>(cout, ", "));	//wypisanie drugi sposób
}
