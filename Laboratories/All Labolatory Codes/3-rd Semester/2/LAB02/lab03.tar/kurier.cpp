#include "kurier.h"
Kurier::Kurier(std::string  n_name):Osoba(n_name){
  
}